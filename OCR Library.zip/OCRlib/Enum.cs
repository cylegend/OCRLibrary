﻿namespace OCRlib
{
    public static class Enum
    {
        public enum MistakeType
        {
            MINOR,
            MODERATE,
            MAJOR,
            NO_MISTAKE
        }
    }
}
